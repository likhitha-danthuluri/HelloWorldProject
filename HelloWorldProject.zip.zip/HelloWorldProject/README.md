# Hello world project
This is simple HTML project that displayes "HELLO WORLD!" ON THE SCREEN.

## Hoe to run
1.Open the index.html file in my web browser.
2.The page will display Hello World! on the screen.

## files included
-index.html
-README.md